<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\CustomerContact;
use App\Models\CustomerSites;

class Customer extends Model
{
    use HasFactory;
    
    protected $table = 'customers';
   protected $fillable = [
       'CST_ID',
       'CST_Code',
       'userId',
       'CST_Name',
       'CST_Website',
       'CST_OfficeAddress',
       'CST_SiteAddress',
       'CST_Note',
       'CST_Status',
       'CCP_Name',
       'CCP_Mobile',
       'CCP_Department',
       'CCP_Email',
       'CCP_Phone1',
       'CCP_Phone2',
       'Ref_Employee',
       'CST_Created_By'
       
    ];
    protected $primaryKey = 'CST_ID';

    public static function rules()
    {
        return [
            'CST_Code' => "required|unique:customers,CST_Code,{$this->primaryKey}",
            'Customer_Name' => "required|unique:customers,CST_Name,{$this->primaryKey}",
            "CCP_Name"             =>          "required",
            "CCP_Mobile"             =>          "required",
            
        ]; 
    }
    public function sites(){
        return $this->hasMany(CustomerSites::class,'CustomerId','CST_ID');
     } 
     public function contact(){
        return $this->hasMany(CustomerContact::class,'CST_ID','CST_ID');
    
     }
    public static function boot() {
        parent::boot();
        self::deleting(function($customer) { // before delete() method call this
            if($customer->sites()->count()>0){
                $customer->sites()->each(function($site) {
                    $site->delete();
                });
            }
           if( $customer->contact()->count()>0){
                $customer->contact()->each(function($contact) {
                    $contact->delete();
                });
           }
            
             // do the rest of the cleanup...
        });
    }
} 